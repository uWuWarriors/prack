package com.example.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class ques3 extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.page3);
        Button buttonNext = findViewById(R.id.btnNext);
        Button buttonSkip = findViewById(R.id.btnSkip);
        super.onCreate(savedInstanceState);
            TextView textView = findViewById(R.id.textView3);
            textView.setText("Get Delivery on time");
        ImageView imageView = findViewById(R.id.imageView5);
        imageView.setImageResource(R.drawable.page3image);
        buttonNext.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(ques3.this, autMenuClass.class);
                startActivity(intent);
            }
        });
        buttonSkip.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(ques3.this, autMenuClass.class);
                startActivity(intent);
            }
        });
    }
}
