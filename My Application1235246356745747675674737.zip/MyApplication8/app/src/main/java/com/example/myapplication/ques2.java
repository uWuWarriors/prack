package com.example.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class ques2 extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.page2);
        Button btnNext = findViewById(R.id.btnNext);
        Button btnSkip = findViewById(R.id.btnSkip);

        super.onCreate(savedInstanceState);
            TextView textView = findViewById(R.id.textView2);
            textView.setText("Online medical & \nHealthcare");
        ImageView imageView = findViewById(R.id.imageView2);
        imageView.setImageResource(R.drawable.page2image);
        btnNext.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(ques2.this, ques3.class);
                startActivity(intent);
            }
        });
        btnSkip.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(ques2.this, autMenuClass.class);
                startActivity(intent);
            }
        });
    }

}
