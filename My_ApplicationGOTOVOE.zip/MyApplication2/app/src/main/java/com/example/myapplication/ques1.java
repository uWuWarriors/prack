package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class ques1 extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.page1);

        Button buttonNext = findViewById(R.id.btnNext1);
        Button buttonSkip = findViewById(R.id.btnSkip);
        super.onCreate(savedInstanceState);
            TextView textView = findViewById(R.id.textView1);
            textView.setText("View and buy \nMedicine online");
        ImageView imageView = findViewById(R.id.imageView);
        imageView.setImageResource(R.drawable.gjgj1);

        buttonNext.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
            Intent intent = new Intent(ques1.this, ques2.class);
            startActivity(intent);
            }
        });
        buttonSkip.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(ques1.this, autMenuClass.class);
                startActivity(intent);
            }
        });
    }

}
