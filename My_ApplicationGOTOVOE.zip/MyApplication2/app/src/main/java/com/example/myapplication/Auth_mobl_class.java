package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Auth_mobl_class extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.auth_mob);
        TextView text1 = findViewById(R.id.textView);
        text1.setText("Enter the verify code");
        TextView textviewEmail = findViewById(R.id.textView2);
        textviewEmail.setText("We just send you a verification code");
        ImageView imageView = findViewById(R.id.imageView6);
        Button buttonCreate = (Button) findViewById(R.id.btnCode);
        buttonCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Auth_mobl_class.this, auth_regclass.class);
                startActivity(intent);
            }
        });
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Auth_mobl_class.this, auth_regclass.class);
                startActivity(intent);
            }
        });
    }
}