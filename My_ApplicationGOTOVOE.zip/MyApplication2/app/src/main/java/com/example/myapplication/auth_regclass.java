package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class auth_regclass extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.auth_reg);
        TextView textPassword = findViewById(R.id.textPass);
        textPassword.setText("Password");
        TextView textviewEmail = findViewById(R.id.textEmail);
        textviewEmail.setText("Email");
        TextView textviewPhone = findViewById(R.id.textPhone);
        textviewPhone.setText("Phone");
        TextView textViewLabel = findViewById(R.id.textLabel);
        textViewLabel.setText("Name");
        Button buttonCreate = (Button) findViewById(R.id.btnCA);
        ImageView imageButton = findViewById(R.id.ImageRegBack);
        buttonCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(auth_regclass.this, Auth_mobl_class.class);
                startActivity(intent);
            }
        });
        imageButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(auth_regclass.this, autMenuClass.class);
                startActivity(intent);
            }
        });
    }
}