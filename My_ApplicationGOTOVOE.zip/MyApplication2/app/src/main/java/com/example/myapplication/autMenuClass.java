package com.example.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class autMenuClass extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.aut_menu);
        super.onCreate(savedInstanceState);
        ImageView imageView = findViewById(R.id.imageAUT);
        imageView.setImageResource(R.drawable.aut);
        Button buttonE = findViewById(R.id.button);
        buttonE.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(autMenuClass.this, auth_logclass.class);
                startActivity(intent);
            }
        });
    }}
